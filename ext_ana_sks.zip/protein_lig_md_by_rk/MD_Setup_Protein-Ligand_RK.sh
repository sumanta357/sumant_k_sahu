#!/bin/bash
source activate gmx
GMX=gmx 

FILE="Alpha_CHEMBL44354_CEFTAZIDIME_4dqy_Protein_A_-9.6.pdb"
LIGNAME="UNL"
grep "HETATM\|CONECT" $FILE > LIG.pdb
sed -i -e 's/UNL/LIG/g' LIG.pdb
obabel -ipdb LIG.pdb -omol > LIG.mol
sed -i -e 's/MOL/LIG/g' LIG.mol
acpype -i LIG.mol -a gaff2
mkdir -p param/ligand
mkdir -p param/receptor
mv LIG* param/ligand/
grep "ATOM" $FILE > receptor.pdb
mv receptor.pdb param/receptor/
tar -czvf param.tar.gz param

#---------  SIMU SETUP  -----------
FF=amber99sb-ildn
WATER=tip3p
BOXTYPE=cubic
BOXSIZE=1
NT=8
GPU_ID=0

WORK_DR=`pwd`
MDP=$WORK_DR/AMBER_P-L_MDP_RK

yes | $GMX pdb2gmx -f param/receptor/receptor.pdb -o param/receptor/receptor_GMX.pdb -water $WATER -ff $FF -ignh -ss -merge all

sed -i -e 's/MOL/LIG/g' param/receptor/receptor_GMX.pdb param/ligand/LIG.acpype/LIG_NEW.pdb
grep -h ATOM param/receptor/receptor_GMX.pdb param/ligand/LIG.acpype/LIG_NEW.pdb > complex.pdb

sed -i -e 's/MOL /LIG /g' param/ligand/LIG.acpype/LIG_GMX.itp
sed -i -e 's/MOL /LIG /g' param/ligand/LIG.acpype/LIG_GMX.gro
cp param/ligand/LIG.acpype/LIG_GMX.* $WORK_DR
cp param/ligand/LIG.acpype/posre_LIG.itp $WORK_DR

echo '
; Ligand position restraints
#ifdef POSRES_LIG
#include "posre_LIG.itp"
#endif
' >> LIG_GMX.itp


cat topol.top | sed -e 's/forcefield.itp"/forcefield.itp"\n#include "LIG_GMX.itp"/' > topol.bak
sed -i -e 's/ #include/#include/g' topol.bak
mv topol.bak topol.top
echo "LIG   1" >> topol.top


#Generate idx group for ligand without hydrogens (for restraints)
#ndx=$($GMX make_ndx -f param/ligand/LIG.acpype/LIG_NEW.pdb -o lig_noh.ndx <<EOF
#r LIG & !a H*
#name 3 LIG-H
#q
#EOF
#)	
#echo "LIG-H" | $GMX genrestr -f param/ligand/LIG.acpype/LIG_NEW.pdb -o posre_LIG.itp -n lig_noh.ndx -fc 1000 1000 1000
#echo '
#	 ; Include Position restraint file
##ifdef POSRES_LIG
##include "posre_LIG.itp"
##endif'  >> LIG_GMX.itp
#
$GMX editconf -f  complex.pdb -o complex_newbox.gro -d $BOXSIZE -bt $BOXTYPE -c
$GMX solvate -cp complex_newbox.gro -cs spc216.gro -o complex_solv.gro -p topol.top
$GMX grompp -f $MDP/ions.mdp -c complex_solv.gro -p topol.top -o ions.tpr --maxwarn 1
echo "SOL" | $GMX genion -s ions.tpr -o complex_solv_ions.gro -p topol.top -pname NA -nname CL -neutral
$GMX grompp -f $MDP/em_steep.mdp -c complex_solv_ions.gro -p topol.top -o em_steep.tpr
$GMX mdrun -v -deffnm em_steep -nt $NT -gpu_id $GPU_ID
$GMX grompp -f $MDP/em_cg.mdp -c em_steep.gro -p topol.top -o em.tpr
$GMX mdrun -v -deffnm em -nt $NT -gpu_id $GPU_ID

echo -e '"Protein" | "LIG"\n q' | gmx make_ndx -f em.gro -o index.ndx

$GMX grompp -f $MDP/nvt_300.mdp -c em.gro -r em.gro -n index.ndx -p topol.top -o nvt_300.tpr
$GMX mdrun -v -deffnm nvt_300 -nt $NT -gpu_id $GPU_ID
$GMX grompp -f $MDP/npt.mdp -c nvt_300.gro -r nvt_300.gro -t nvt_300.cpt -n index.ndx -p topol.top -o npt_ab.tpr
$GMX mdrun -v -deffnm npt_ab -nt $NT -gpu_id $GPU_ID
$GMX grompp -f $MDP/md.mdp -c npt_ab.gro -t npt_ab.cpt -n index.ndx -p topol.top -o md_complex_prod.tpr
$GMX mdrun -v -deffnm md_complex_prod -nt $NT -gpu_id $GPU_ID
echo "Protein_LIG System" | $GMX trjconv -s md_complex_prod.tpr -f md_complex_prod.trr -center -pbc mol -ur compact -o md_noPBC.xtc -n index.ndx
echo "Protein_LIG System" | $GMX trjconv -s md_complex_prod.tpr -f md_noPBC.xtc -fit rot+trans -o md_fit.xtc -n
rm -rf md_noPBC.xtc

echo "Backbone Backbone" | $GMX rms -s md_complex_prod.tpr -f md_fit.xtc -n index.ndx -o "Protein_"$FILE"_rmsd".xvg -tu ns 
echo "Protein" | $GMX rmsf -s md_complex_prod.tpr -f md_fit.xtc -n index.ndx -o "Protein_"$FILE"_rmsf".xvg -res
echo "LIG LIG" | $GMX rms -s md_complex_prod.tpr -f md_fit.xtc -n index.ndx -o "LIG_"$FILE"_rmsd".xvg -tu ns
echo "LIG" | $GMX rmsf -s md_complex_prod.tpr -f md_fit.xtc -o "LIG_"$FILE"_rmsf".xvg
