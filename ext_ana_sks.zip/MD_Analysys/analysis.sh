#!bin/bash

source /home/apps/gromacs-2023-3/bin/GMXRC


#gmx trjconv -f /replica_1/md_50.xtc -dt 100 -o replica_1/traj_short.xtc 

echo 1 0 | gmx trjconv -s ../md_complex_prod.tpr -f ../md_complex_prod.xtc -o md_noj.xtc -pbc nojump -ur compact  -center -n ../index.ndx

echo 1 0| gmx trjconv -s ../md_complex_prod.tpr -f md_noj.xtc -fit rot+trans -o md_fit.xtc -n ../index.ndx

# Analysis ################

#echo 12 0 | gmx energy -f replica_1/results/mini/em.edr -o PE.xvg

#echo 17 0 | gmx energy -f replica_1/results/nvt/nvt_300.edr -o temp.xvg

#echo 19 0 | gmx energy -f replica_1/results/npt/npt_ab.edr -o pressure.xvg

#echo 25 0 | gmx energy -f replica_1/results/npt/npt_ab.edr -o density.xvg

#echo 4 4 | gmx rms -f ../md_fit.xtc -s ../md_complex_prod.tpr  -o rmsd_bkbone.xvg -tu ns -n ../index.ndx

#echo 22 22 | gmx rms -f ../md_fit.xtc -s ../md_complex_prod.tpr  -o rmsd_protein_mg.xvg -tu ns -n ../index.ndx
#echo 23 23 | gmx rms -f ../md_fit.xtc -s ../md_complex_prod.tpr  -o rmsd_protein_gcp.xvg -tu ns -n ../index.ndx
#echo 24 24 | gmx rms -f ../md_fit.xtc -s ../md_complex_prod.tpr  -o rmsd_protein_6ic_mg.xvg -tu ns -n ../index.ndx
#echo 25 25 | gmx rms -f ../md_fit.xtc -s ../md_complex_prod.tpr  -o rmsd_protein_gcp_61c_mg.xvg -tu ns -n ../index.ndx

#echo 3 | gmx rmsf -f ../md_fit.xtc  -s ../md_complex_prod.tpr  -o rmsf_b.xvg -res ../index.ndx
#cho 25 | gmx rmsf -f ../md_fit.xtc  -s ../md_complex_prod.tpr  -o rmsf_gcp_6ic_mg.xvg -res ../index.ndx

#echo 4 | gmx sasa -s ../md_complex_prod.tpr -f ../md_fit.xtc  -o sasa_b.xvg -tu ns  ../index.ndx


#echo 2 | gmx gyrate -s ../md_complex_prod.tpr -f ../md_fit.xtc  -o rg_b.xvg ../index.ndx


#mkdir ANA

#mv *.xvg ANA

#clustering ##############

mkdir clust
#################################################################################################################################################################################
echo 27 27 | gmx rms -s ../md_complex_prod.tpr -f md_fit.xtc  -m clust/rmsd.xpm -o clust/rmsd.xvg -n ../index.ndx

echo 27  27 | gmx cluster -f md_fit.xtc -s ../md_complex_prod.tpr -method gromos -cutoff 0.25 -dm clust/rmsd.xpm -dist clust/rmsd_dist.xvg -sz clust/clust_size.xvg -ntr clust/clust_trans.xvg -clid clust/clust_id.xvg -clndx clust/clusters.ndx -cl clust/clust.pdb -wcl 1 -n ../index.ndx
################################################################################################################################################################################
# INDEX FILE NOT ADDED

# PCA analysis ##############

echo PCA Analysis started....

#gmx convert-tpr -s md_50_fikfype_up.tpr -o protein.tpr

mkdir pca

echo 27  27 | gmx covar -f md_fit.xtc -s ../md_complex_prod.tpr -v pca/eignvec.trr -o pca/eigenval.xvg -n ../index.ndx 

#pc 1
echo 27  27 | gmx anaeig -f md_fit.xtc  -s ../md_complex_prod.tpr -v pca/eignvec.trr -eig pca/eigenval.xvg -rmsf pca/rmsf_1.xvg -proj pca/pc1.xvg -first 1 -last 1 -2d -entropy  -extr pca/pc1.pdb -nframes 500 -tu ns -n ../index.ndx

#pc 2
echo 27  27 | gmx anaeig -f md_fit.xtc  -s ../md_complex_prod.tpr -v pca/eignvec.trr -eig pca/eigenval.xvg -rmsf pca/rmsf_2.xvg -proj pca/pc2.xvg -first 2 -last 2 -2d -entropy  -extr pca/pc2.pdb -nframes 500 -tu ns -n ../index.ndx

#pc 3
echo 27  27 | gmx anaeig -f md_fit.xtc  -s ../md_complex_prod.tpr -v pca/eignvec.trr -eig pca/eigenval.xvg -rmsf pca/rmsf_3.xvg -proj pca/pc3.xvg -first 3 -last 3 -2d -entropy  -extr pca/pc3.pdb -nframes 500 -tu ns -n ../index.ndx

#pc1v2
echo 27  27 | gmx anaeig -f md_fit.xtc  -s ../md_complex_prod.tpr -eig pca/eigenval.xvg -v pca/eignvec.trr  -first 1 -last 2 -2d  pca/pc1v2.xvg -n ../index.ndx
#pc2v3
echo 27  27 | gmx anaeig -f md_fit.xtc  -s ../md_complex_prod.tpr -eig pca/eigenval.xvg -v pca/eignvec.trr  -first 2 -last 3 -2d  pca/pc2v3.xvg -n ../index.ndx
#pc1v3
echo 27  27 | gmx anaeig -f md_fit.xtc  -s ../md_complex_prod.tpr  -eig pca/eigenval.xvg -v pca/eignvec.trr  -first 1 -last 3 -2d  pca/pc1v3.xvg -n ../index.ndx


echo COMPLETED.....
