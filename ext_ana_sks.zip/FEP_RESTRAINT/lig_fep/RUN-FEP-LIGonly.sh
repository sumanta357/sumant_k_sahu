G=/usr/local/gromacs/bin/gmx;

$G editconf -f complex.gro -o newbox.gro -bt cubic -c -d 1.0
$G solvate -cp newbox.gro -cs spc216.gro -p topol.top -o solv.gro


# PREPARING INDEX

$G grompp -f em.mdp -c solv_ions.gro -p topol.top -o em.tpr -maxwarn 5
$G mdrun -v -deffnm em -nt 8 -gpu_id $GPU

echo "
q" | $G make_ndx -f em.gro -o index.ndx

exit
