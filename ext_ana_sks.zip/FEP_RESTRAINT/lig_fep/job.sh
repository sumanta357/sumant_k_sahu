#!/bin/bash



# Set some environment variables 
FREE_ENERGY=`pwd`
echo "Free energy home directory set to $FREE_ENERGY"
MDP=$FREE_ENERGY/MDP
echo ".mdp files are stored in $MDP"

# Change to the location of your GROMACS-2018 installation
GMX=/usr/local/gromacs/bin

#cd Lambda_19/Production_MD/
#$GMX/gmx mdrun -deffnm md19 -nt 8 -gpu_id 5;
#cd ../../;

#pwd

for (( i=0; i<26; i++ ))
do
    LAMBDA=$i

    # A new directory will be created for each value of lambda and
    # at each step in the workflow for maximum organization.

    mkdir Lambda_$LAMBDA
    cd Lambda_$LAMBDA

    ##############################
    # ENERGY MINIMIZATION STEEP  #
    ##############################
    #echo "Starting minimization for lambda = $LAMBDA..." 

    mkdir EM
    cd EM
    # Iterative calls to grompp and mdrun to run the simulations

    cp $FREE_ENERGY/*.itp .;
    $GMX/gmx grompp -f $MDP/em_$LAMBDA.mdp -c $FREE_ENERGY/solv.gro -p $FREE_ENERGY/topol.top -o em$LAMBDA.tpr -maxwarn 5

    $GMX/gmx mdrun -v -deffnm em$LAMBDA -nt 8 -gpu_id 5 

   # sleep 10

    #####################
    # NVT EQUILIBRATION #
    #####################
    echo "Starting constant volume equilibration..."

   cd ../; 
    mkdir NVT
    cd NVT
#cp -r $FREE_ENERGY/charmm36-mar2019.ff .; cp $FREE_ENERGY/*.itp .; cp $FREE_ENERGY/index.ndx .; 

#LIGAND RESTRAIN

#echo "
#0 & ! a H*
#q" | $GMX/gmx make_ndx -f $FREE_ENERGY/FK5.gro -o $FREE_ENERGY/index_lig.ndx

#echo "
#3" | $GMX/gmx genrestr -f $FREE_ENERGY/FK5.gro -n $FREE_ENERGY/index_lig.ndx -o $FREE_ENERGY/posre_lig.itp -fc 1000 1000 1000

# PREPARING INDEX 
#echo "
#1 | 13
#q" | $GMX/gmx make_ndx -f ../EM/em$LAMBDA.gro -o index.ndx

$GMX/gmx grompp -f $MDP/nvt_$LAMBDA.mdp -r ../EM/em$LAMBDA.gro -c ../EM/em$LAMBDA.gro -p $FREE_ENERGY/topol.top -n $FREE_ENERGY/index.ndx -o nvt$LAMBDA.tpr -maxwarn 5

    $GMX/gmx mdrun -v -deffnm nvt$LAMBDA -nt 8 -gpu_id 5

    echo "Constant volume equilibration complete."

    sleep 10

    #####################
    # NPT EQUILIBRATION #
    #####################
    echo "Starting constant pressure equilibration..."

    cd ../
    mkdir NPT
    cd NPT
    #cp -r $FREE_ENERGY/charmm36-mar2019.ff .; cp $FREE_ENERGY/*.itp .; cp $FREE_ENERGY/index.ndx .;

$GMX/gmx grompp -f $MDP/npt_$LAMBDA.mdp -r ../NVT/nvt$LAMBDA.gro -c ../NVT/nvt$LAMBDA.gro -p $FREE_ENERGY/topol.top -n $FREE_ENERGY/index.ndx -t ../NVT/nvt$LAMBDA.cpt -o npt$LAMBDA.tpr -maxwarn 5

    $GMX/gmx mdrun -v -deffnm npt$LAMBDA -nt 8 -gpu_id 5

    echo "Constant pressure equilibration complete."

    sleep 10

    #################
    # PRODUCTION MD #
    #################
    echo "Starting production MD simulation..."

    cd ../
    mkdir Production_MD
    cd Production_MD
#cp -r $FREE_ENERGY/charmm36-mar2019.ff .; cp $FREE_ENERGY/*.itp .; cp $FREE_ENERGY/index.ndx .;
    $GMX/gmx grompp -f $MDP/md_$LAMBDA.mdp -r ../NPT/npt$LAMBDA.gro -c ../NPT/npt$LAMBDA.gro -p $FREE_ENERGY/topol.top -n $FREE_ENERGY/index.ndx -t ../NPT/npt$LAMBDA.cpt -o md$LAMBDA.tpr -maxwarn 5
    

    $GMX/gmx mdrun -deffnm md$LAMBDA -nt 8 -gpu_id 5

    echo "Production MD complete."

    # End
    echo "Ending. Job completed for lambda = $LAMBDA"

    cd $FREE_ENERGY
#   exit 
done

exit;
