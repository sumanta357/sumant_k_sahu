G=/usr/local/gromacs/bin/gmx;
GPU=4;
echo "
6
" | $G pdb2gmx -f prot.pdb -o prot.gro -water tip3p -ignh

cp prot.gro prot2.gro;
sed -n '2p' prot2.gro | sed 's: ::g' > numb-prot
sed -i '2d' prot2.gro

sed -n '2p' lig.gro | sed 's: ::g' > numb-lig
cp lig.gro lig2.gro
sed -i '1,2d' lig2.gro

tail -1 prot2.gro > veloc.prolig
sed -i '$ d' prot2.gro;

sed -i '/^$/d' lig2.gro;
tail -1 lig2.gro >> veloc.prolig
sed -i '$ d' lig2.gro;
cat veloc.prolig | tr "\n" " "| awk '{print}' | sed 's:    :   :g' > VELOCITY_BOTH
cat prot2.gro lig2.gro VELOCITY_BOTH > complex.gro

echo "
`cat numb-prot`+`cat numb-lig`
quit" | bc > new-number;

sed -i '2 i '$(cat new-number)'' complex.gro;
echo "LIG                 1" >> topol.top;
echo "**************************ASSUMING THE moleculetype is renamed to LIG*****************";

head -21 topol.top > 1.txt; sed -n '22,10000000000000p' topol.top > 2.txt;

echo "
; Include ligand topology
#include "\"lig.itp\""

; Ligand position restraints
#ifdef POSRES_LIG
#include "\"posre_lig.itp\""
#endif
" >> 1.txt

cat 1.txt 2.txt > topol.top

echo "


";

echo "********************** STARTING SOLVATION AND NEXT STEPS *********************";
$G editconf -f complex.gro -o newbox.gro -bt cubic -c -d 1.0
$G solvate -cp newbox.gro -cs spc216.gro -p topol.top -o solv.gro

$G grompp -f ions.mdp -c solv.gro -p topol.top -o ions.tpr -maxwarn 5

echo "15
"| $G genion -s ions.tpr -o solv_ions.gro -p topol.top -pname NA -nname CL -neutral


#LIGAND RESTRAIN
echo "
0 & ! a H*
q" | $G make_ndx -f lig.gro -o index_lig.ndx

echo "
3" | $G genrestr -f lig.gro -n index_lig.ndx -o posre_lig.itp -fc 1000 1000 1000

# PREPARING INDEX

$G grompp -f em.mdp -c solv_ions.gro -p topol.top -o em.tpr -maxwarn 5
$G mdrun -v -deffnm em -nt 8 -gpu_id $GPU

echo "
1 | 13 
q" | $G make_ndx -f em.gro -o index.ndx

cp solv_ions.gro complex_solv_ions.gro
exit
$G grompp -f nvt.mdp -r em.gro -c em.gro -p topol.top -n index.ndx -o nvt.tpr -maxwarn 5
$G mdrun -v -deffnm nvt -gpu_id $GPU -nt 8 

$G grompp -f npt.mdp -r nvt.gro -c nvt.gro -p topol.top -n index.ndx -o npt.tpr -maxwarn 5
$G mdrun -v -deffnm npt -gpu_id $GPU -nt 8

$G grompp -f md.mdp -c npt.gro -r npt.gro -t npt.cpt -p topol.top -n index.ndx -o md.tpr -maxwarn 5
$G mdrun -v -deffnm md -gpu_id $GPU -nt 8


G=/usr/local/gromacs/bin/gmx

echo "
1
0
q" | $G trjconv -s md.tpr -f md.xtc -o md_noPBC.xtc -pbc mol -center

echo "Protein System" | $G trjconv -s md.tpr -f md_noPBC.xtc -o "md_clean_full.xtc" -fit rot+trans
        echo "Protein non-Water"| $G trjconv -s "md.tpr" -f "md_clean_full.xtc" -o "md_clean_nowat.xtc" -fit rot+trans
        echo "Protein non-Water" | $G trjconv -s "md.tpr" -f "md_clean_full.xtc" -o "md_clean_nowat.pdb" -pbc nojump -ur compact -center -b 0 -e 0

echo "
4
4
q" | $G rms -s md.tpr -f md_noPBC.xtc -o rmsd.xvg -tu ns

echo "
13
13
q" | $G rms -s md.tpr -f md_noPBC.xtc -o rmsd-LIG.xvg -tu ns

echo "
4
4
q" | $G rms -s em.tpr -f md_noPBC.xtc -o rmsd_xtal.xvg -tu ns

echo "
1
q" | $G gyrate -s md.tpr -f md_noPBC.xtc -o gyrate.xvg

echo "
3
q" | $G rmsf -s md.tpr -f md_noPBC.xtc -o rmsf.xvg -res

mkdir RESULTS;
mv rmsd*.xvg gyrate.xvg rmsf.xvg RESULTS/;

echo "***************** DONE analysing MD output *****************";

