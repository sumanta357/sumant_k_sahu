


import pymol as p


p.cmd.load('complex_solv_ions.gro')

prot = input('Enter protein residue name')

protnum = input('Enter protein residue ID')


lig = input('Enter lig residue name')

lignum = input('Enter lig residue ID')


lig1 = input("Enter centre lig atom:")

lig2 = input("Enter left lig atom:")

lig3 = input("Enter right lig atom:")


d1 = "/complex_solv_ions///"+str(prot)+"`"+str(protnum)+"/CA"

d2 = "/complex_solv_ions///"+str(lig)+"`"+str(lignum)+"/"+str(lig1)

d = p.cmd.get_distance(atom1=d1,atom2=d2)


we = open('complex_solv_ions.gro', 'r')


lines = we.readlines()

chk1 = str(protnum)+str(prot)
for l in lines:
    
    if chk1 in l:
        if 'CA' in l:
            sk = l.split()
            indx1 = str(sk[2])
        
chk2 = str(lignum)+str(lig)
chk3 = str(lig1)

for l in lines:
    
    if chk2 in l:
        sk = l.split()
        if chk3 == str(sk[1]):
            indx2 = str(sk[2])
        
        
a1 = "/complex_solv_ions///"+str(prot)+"`"+str(protnum)+"/CA"

a2 = "/complex_solv_ions///"+str(lig)+"`"+str(lignum)+"/"+str(lig1)

a3 = "/complex_solv_ions///"+str(lig)+"`"+str(lignum)+"/"+str(lig2)

an1 = p.cmd.get_angle(atom1=a1,atom2=a2,atom3=a3)



chk1 = str(protnum)+str(prot)
for l in lines:
    
    if chk1 in l:
        if 'CA' in l:
            sk = l.split()
            indx3 = str(sk[2])
            print(indx3)

chk2 = str(lignum)+str(lig)
chk3 = str(lig1)

for l in lines:
    
    if chk2 in l:
        sk = l.split()
        if chk3 == str(sk[1]):
            indx4 = str(sk[2])
            print(indx4)
            
            
chk2 = str(lignum)+str(lig)
chk3 = str(lig2)

for l in lines:
    
    if chk2 in l:
        sk = l.split()
        if chk3 == str(sk[1]):
            indx5 = str(sk[2])
            print(indx5)
an1 = round(an1, 3)     
print(an1)


a1 = "/complex_solv_ions///"+str(prot)+"`"+str(protnum)+"/CA"

a2 = "/complex_solv_ions///"+str(lig)+"`"+str(lignum)+"/"+str(lig1)

a3 = "/complex_solv_ions///"+str(lig)+"`"+str(lignum)+"/"+str(lig3)

an2 = p.cmd.get_angle(atom1=a1,atom2=a2,atom3=a3)


chk1 = str(protnum)+str(prot)
for l in lines:
    
    if chk1 in l:
        if 'CA' in l:
            sk = l.split()
            indx6 = str(sk[2])
            print(indx6)

chk2 = str(lignum)+str(lig)
chk3 = str(lig1)

for l in lines:
    
    if chk2 in l:
        sk = l.split()
        if chk3 == str(sk[1]):
            indx7 = str(sk[2])
            print(indx7)
            
            
chk2 = str(lignum)+str(lig)
chk3 = str(lig3)

for l in lines:
    
    if chk2 in l:
        sk = l.split()
        if chk3 == str(sk[1]):
            indx8 = str(sk[2])
            print(indx8)
an2 = round(an2, 3)     
print(an2)


a0 = "/complex_solv_ions///"+str(prot)+"`"+str(protnum)+"/CA"

a1 = "/complex_solv_ions///"+str(lig)+"`"+str(lignum)+"/"+str(lig3)

a2 = "/complex_solv_ions///"+str(lig)+"`"+str(lignum)+"/"+str(lig1)

a3 = "/complex_solv_ions///"+str(lig)+"`"+str(lignum)+"/"+str(lig2)

an3 = p.cmd.get_dihedral(atom1=a0,atom2=a1,atom3=a2,atom4=a3)


chk1 = str(protnum)+str(prot)
for l in lines:
    
    if chk1 in l:
        if 'CA' in l:
            sk = l.split()
            indx9 = str(sk[2])
            print(indx9)

chk2 = str(lignum)+str(lig)
chk3 = str(lig3)

for l in lines:
    
    if chk2 in l:
        sk = l.split()
        if chk3 == str(sk[1]):
            indx10 = str(sk[2])
            print(indx10)
            
            
chk2 = str(lignum)+str(lig)
chk3 = str(lig1)

for l in lines:
    
    if chk2 in l:
        sk = l.split()
        if chk3 == str(sk[1]):
            indx11 = str(sk[2])
            print(indx11)
            
            
chk2 = str(lignum)+str(lig)
chk3 = str(lig2)

for l in lines:
    
    if chk2 in l:
        sk = l.split()
        if chk3 == str(sk[1]):
            indx12 = str(sk[2])
            print(indx12)
            
            
            
            
            
an3 = round(an3, 3)     
print(an3)


a0 = "/complex_solv_ions///"+str(prot)+"`"+str(protnum)+"/C"

a1 = "/complex_solv_ions///"+str(prot)+"`"+str(protnum)+"/CA"

a2 = "/complex_solv_ions///"+str(lig)+"`"+str(lignum)+"/"+str(lig1)

a3 = "/complex_solv_ions///"+str(lig)+"`"+str(lignum)+"/"+str(lig2)

an4 = p.cmd.get_dihedral(atom1=a0,atom2=a1,atom3=a2,atom4=a3)


chk1 = str(protnum)+str(prot)
for l in lines:
    
    if chk1 in l:
        
        sk = l.split()
        if 'C' == str(sk[1]):
            
            indx13 = str(sk[2])
            print(indx13)
            
for l in lines:
    
    if chk1 in l:
        if 'CA' in l:
            sk = l.split()
            indx14 = str(sk[2])
            print(indx14)

chk2 = str(lignum)+str(lig)
chk3 = str(lig1)

for l in lines:
    
    if chk2 in l:
        sk = l.split()
        if chk3 == str(sk[1]):
            indx15 = str(sk[2])
            print(indx15)
            
            
chk2 = str(lignum)+str(lig)
chk3 = str(lig2)

for l in lines:
    
    if chk2 in l:
        sk = l.split()
        if chk3 == str(sk[1]):
            indx16 = str(sk[2])
            print(indx16)
            
            
 
            
            
an4 = round(an4, 3)     
print(an4)

a0 = "/complex_solv_ions///"+str(prot)+"`"+str(protnum)+"/C"

a1 = "/complex_solv_ions///"+str(prot)+"`"+str(protnum)+"/CA"

a2 = "/complex_solv_ions///"+str(lig)+"`"+str(lignum)+"/"+str(lig1)

a3 = "/complex_solv_ions///"+str(lig)+"`"+str(lignum)+"/"+str(lig3)

an5 = p.cmd.get_dihedral(atom1=a0,atom2=a1,atom3=a2,atom4=a3)


chk1 = str(protnum)+str(prot)
for l in lines:
    
    if chk1 in l:
        
        sk = l.split()
        if 'C' == str(sk[1]):
            
            indx17 = str(sk[2])
            print(indx17)
            
for l in lines:
    
    if chk1 in l:
        if 'CA' in l:
            sk = l.split()
            indx18 = str(sk[2])
            print(indx18)

chk2 = str(lignum)+str(lig)
chk3 = str(lig1)

for l in lines:
    
    if chk2 in l:
        sk = l.split()
        if chk3 == str(sk[1]):
            indx19 = str(sk[2])
            print(indx19)
            
            
chk2 = str(lignum)+str(lig)
chk3 = str(lig3)

for l in lines:
    
    if chk2 in l:
        sk = l.split()
        if chk3 == str(sk[1]):
            indx20 = str(sk[2])
            print(indx20)
            
            
 
            
            
an5 = round(an5, 3)     
print(an5)


fv = open('topol.top', 'r')

fv1 = open('topoln5.top', 'a+')
alla = fv.readlines()

for a in alla:
    
    if 'dis1    dis2' in a:
        print('yes')
        a = a.replace('dis1', str(indx1))


        a = a.replace('dis2', str(indx2))
        d = round(d, 3)
        a = a.replace('val1', str(d))
    if 'ang1    ang2  ang3' in a:
        
        a = a.replace('ang1', str(indx3))


        a = a.replace('ang2', str(indx4))

        a = a.replace('ang3', str(indx5))
        
        a = a.replace('val2', str(an1))
        
    if 'ang4    ang5  ang6' in a:
        
        a = a.replace('ang4', str(indx6))


        a = a.replace('ang5', str(indx7))

        a = a.replace('ang6', str(indx8))
        
        a = a.replace('val3', str(an2))
        
    if 'die1  die2  die3  die4' in a:
        
        a = a.replace('die1', str(indx9))

        a = a.replace('die2', str(indx10))

        a = a.replace('die3', str(indx11))
        
        a = a.replace('die4', str(indx12))
        
        a = a.replace('val4', str(an3))
        
    if 'die5  die6  die7  die8' in a:
        
        a = a.replace('die5', str(indx13))

        a = a.replace('die6', str(indx14))

        a = a.replace('die7', str(indx15))
        
        a = a.replace('die8', str(indx16))
        
        a = a.replace('val5', str(an4))
        
        
    if 'die9  die10  die11  die12' in a:
        
        a = a.replace('die9', str(indx17))

        a = a.replace('die10', str(indx18))

        a = a.replace('die11', str(indx19))
        
        a = a.replace('die12', str(indx20))
        
        a = a.replace('val6', str(an5))
        
    
        
    fv1.write(a)
    
fv1.close()
