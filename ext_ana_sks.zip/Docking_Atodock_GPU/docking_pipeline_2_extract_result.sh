#!/bin/bash

# Path settings
export MGLT="/home/sumanta.kumar@sapt.local/test/mgltools_x86_64Linux2_1.5.7/MGLToolsPckgs/AutoDockTools/Utilities24"
export VinaPath="/home/user/anaconda3/envs/docking/bin"
export autogrid4="/home/user/anaconda3/envs/docking/bin/autogrid4"
export pthnsh="/home/sumanta.kumar@sapt.local/test/mgltools_x86_64Linux2_1.5.7/bin"
export REC_PDBQT_PATH="/mnt/AI_Linux_Web_API_Server/sumanta.kumar/UMICH2_REVISIT/DOCKING_NCES/mod_sp10/rec.pdbqt"

# Define absolute result folders
RESULT_FOLDER="$(pwd)/result_csv"
mkdir -p "$RESULT_FOLDER"
RESULT_FILE="$RESULT_FOLDER/best_docking_results.csv"
ERROR_LOG="$RESULT_FOLDER/error.log"
> "$ERROR_LOG"
echo "Compound_ID,Run_Number,Binding_Energy,Cluster_Size,Renamed_File" > "$RESULT_FILE"

# Extract results using Python with improved filtering
extract_best_pose_py() {
    python3 - <<EOF
import os, re, csv

result_dir = "$RESULT_FOLDER"
csv_path = os.path.join(result_dir, "best_docking_results.csv")
error_log = os.path.join(result_dir, "error.log")

with open(csv_path, 'a', newline='') as f, open(error_log, 'a') as err_file:
    writer = csv.writer(f)
    for folder in os.listdir("."):
        if not os.path.isdir(folder): continue
        dlg_file = os.path.join(folder, "docking.log.dlg")
        if not os.path.exists(dlg_file):
            dlg_file = os.path.join(folder, "docking.log")
        if not os.path.exists(dlg_file):
            err_file.write(f"Error: docking log not found for {folder}\n")
            continue

        with open(dlg_file) as dlg:
            lines = dlg.readlines()

        poses = []
        for line in lines:
            match = re.match(r"\s*(\d+)\s*\|\s*(-?\d+\.\d+)\s*\|\s*(\d+)\s*\|\s*(-?\d+\.\d+)\s*\|\s*(\d+)", line)
            if match:
                cluster_rank = int(match.group(1))
                lowest_energy = float(match.group(2))
                run_number = int(match.group(3))
                mean_energy = float(match.group(4))
                num_in_cluster = int(match.group(5))
                poses.append((num_in_cluster, lowest_energy, run_number, cluster_rank))

        if not poses:
            err_file.write(f"Warning: No valid docking poses found for {folder}\n")
            continue

        # Sort clusters by size (Num in Clus) in descending order, then take the top 5
        top5 = sorted(poses, key=lambda x: (-x[0], x[1]))[:5]
        for num_in_cluster, lowest_energy, run_number, cluster_rank in top5:
            pdbqt_file = f"{folder}_docked_run{run_number}_entity1.pdbqt"
            if not os.path.exists(os.path.join(folder, pdbqt_file)):
                possible_files = [f for f in os.listdir(folder) if f"_run{run_number}_" in f and f.endswith(".pdbqt")]
                if possible_files:
                    pdbqt_file = os.path.join(folder, possible_files[0])
                else:
                    err_file.write(f"Warning: PDBQT file not found for {folder}, Run {run_number}, Cluster {cluster_rank}\n")
                    continue

            new_filename = f"bestdock_{folder}_run{run_number}_cluster{cluster_rank}.pdbqt"
            os.rename(os.path.join(folder, pdbqt_file), os.path.join(result_dir, new_filename))
            writer.writerow([folder, run_number, lowest_energy, num_in_cluster, new_filename])
EOF
}

# Main pipeline
main() {
    echo "Docking completed! Processing top 5 cluster results using Python..."
    extract_best_pose_py
    echo "Pipeline completed successfully."
}

main

