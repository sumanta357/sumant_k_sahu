#!/bin/bash

# === NOTE ===
echo "⚠️  IMPORTANT: Before using this script, make sure all paths inside the script are correctly set."
echo "⚠️  Paths to MGLTools, AutoDock, Python shell, and receptor file must be verified."
echo "⚠️  You need receptor.pdbqt smiles.csv x y z coordinates anf npts grid centers x y z , path will be CWD
echo "⚠️  The SMILES CSV file must have the following format:"
echo ""
echo "Example:"
echo "Compound_ID,SMILES"
echo "C001,C(C(=O)O)c1ccccc1"
echo "C002,CC(C)C(=O)O"
echo "C003,CCN(CC)CC"

echo "✅  If you want to extract best 5 cluster pose having lowest binding energy from each cluster after completion of this docking pipeline just run ✅bash extract_result.sh✅"

# === Path Settings ===
export MGLT=/home/sumanta.kumar@sapt.local/test/mgltools_x86_64Linux2_1.5.7/MGLToolsPckgs/AutoDockTools/Utilities24
export VinaPath=/home/sumanta.kumar@sapt.local/anaconda3/envs/docking/bin
export autogrid4=/home/sumanta.kumar@sapt.local/anaconda3/bin/autogrid4
export pthnsh=/home/sumanta.kumar@sapt.local/test/mgltools_x86_64Linux2_1.5.7/bin

echo "🧑‍💻written by Sumanta K. Sahu" 🧑‍💻 Happy Docking...👤"
# === User Inputs ===
read -p "Enter receptor PDBQT filename (must be in current directory): " REC_PDBQT_FILENAME
read -p "Enter full path to SMILES CSV file: " input_csv
read -p "Enter grid center X coordinate: " GRID_X
read -p "Enter grid center Y coordinate: " GRID_Y
read -p "Enter grid center Z coordinate: " GRID_Z
read -p "Enter npts X dimension: " NPTS_X
read -p "Enter npts Y dimension: " NPTS_Y
read -p "Enter npts Z dimension: " NPTS_Z

# === Ligand Preparation ===
create_pdbqt_from_smiles() {
    csv_file=$1
    while IFS=, read -r compound_id smiles; do
        if [ "$compound_id" != "Compound_ID" ]; then
            mkdir -p "$compound_id"
            echo "$smiles" > "${compound_id}/${compound_id}.smi"
            echo "[$compound_id] Generating MOL2 from SMILES..."
            obabel -ismi "${compound_id}/${compound_id}.smi" -omol2 -O "${compound_id}/${compound_id}.mol2" --gen3D --minimize -h

            if [ ! -f "${compound_id}/${compound_id}.mol2" ]; then
                echo "❌ Error: MOL2 file for $compound_id was not created. Skipping..."
                continue
            fi
            cd "$compound_id"

            echo "[$compound_id] Preparing ligand PDBQT..."
            "${pthnsh}/pythonsh" "${MGLT}/prepare_ligand4.py" -l "${compound_id}.mol2" -o "${compound_id}.pdbqt"
            cd ../ 
        fi
    done < "$csv_file"
}

# === Docking Execution ===
run_docking() {
    csv_file=$1
    while IFS=, read -r compound_id smiles; do
        if [ "$compound_id" != "Compound_ID" ]; then
            if [ -d "$compound_id" ]; then 
                cd "$compound_id"
                echo "[$compound_id] Starting docking..."
                ligand_file="${compound_id}.pdbqt"
                if [ ! -f "$ligand_file" ]; then
                    echo "❌ Ligand file for $compound_id not found!"
                    cd ../
                    continue
                fi

                cp "../$REC_PDBQT_FILENAME" . || { echo "❌ Failed to copy receptor file."; cd ../; continue; }
                $pthnsh/pythonsh $MGLT/prepare_gpf4.py -l "$ligand_file" -r rec.pdbqt -p spacing=0.403 -p npts="${NPTS_X},${NPTS_Y},${NPTS_Z}" -p gridcenter="${GRID_X},${GRID_Y},${GRID_Z}" -o ${compound_id}.gpf
                sed -i 's/receptor.pdbqs/rec.pdbqt/g' ${compound_id}.gpf
                $autogrid4 -p ${compound_id}.gpf -l ${compound_id}.glg

                $pthnsh/pythonsh $MGLT/prepare_dpf42.py -l "$ligand_file" -r rec.pdbqt -p ga_num_evals=30000000 -p ga_num_generations=30000 -p ga_pop_size=200 -p ga_run=20 -o Dock${compound_id}.dpf

                autodock_gpu_256wi -L "$ligand_file" -M rec.maps.fld --dlgoutput 1 --npdb 1 --A 0 --nrun 1000 --nev 3000000 --ngen 100000 --lsit 600 --psize 600 --mrat 1 -N docking.log  

                echo "[$compound_id] Docking completed."
                cd ../
            fi
        fi
    done < "$csv_file"
}

# === Convert Docked Ligands to PDB ===
convert_pdbqt_to_pdb() {
    csv_file=$1
    while IFS=, read -r compound_id smiles; do
        if [ "$compound_id" != "Compound_ID" ]; then
            if [ -d "$compound_id" ]; then
                cd "$compound_id"
                ligand_file="${compound_id}.pdbqt"
                if [ -f "$ligand_file" ]; then
                    echo "[$compound_id] Converting PDBQT to PDB..."
                    obabel "$ligand_file" -O "${compound_id}.pdb"
                else
                    echo "❌ Ligand file for $compound_id not found!"
                fi
                cd ../
            fi
        fi
    done < "$csv_file"
}

# === Main Workflow ===
main() {
    echo "🔄 Starting ligand preparation..."
    create_pdbqt_from_smiles "$input_csv"
    echo "🚀 Starting docking..."
    run_docking "$input_csv"
    echo "📦 Converting docked ligands to PDB..."
    convert_pdbqt_to_pdb "$input_csv"
    echo "✅ Docking pipeline completed."
    echo "🔄written by Sumanta K Sahu🔄"
}

main
