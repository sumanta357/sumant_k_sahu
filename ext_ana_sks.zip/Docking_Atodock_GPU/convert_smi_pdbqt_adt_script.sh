#!/bin/bash

# Environment setup
export MGLT=/home/sumanta.kumar@sapt.local/test/mgltools_x86_64Linux2_1.5.7/MGLToolsPckgs/AutoDockTools/Utilities24
export VinaPath=/home/sumanta.kumar@sapt.local/anaconda3/envs/docking/bin
export autogrid4=/home/sumanta.kumar@sapt.local/anaconda3/envs/docking/bin/autogrid4
export pthnsh=/home/sumanta.kumar@sapt.local/test/mgltools_x86_64Linux2_1.5.7/bin
export REC_PDBQT_PATH=/home/sumanta.kumar@sapt.local/UMICH2/sp_shared_docking/cpu_docking/rec.pdbqt  # Receptor PDBQT path

# Function to convert SMILES to PDBQT
create_pdbqt_from_smiles() {
    csv_file=$1
    while IFS=, read -r compound_id smiles; do
        if [ "$compound_id" != "Compound_ID" ]; then  # Skip header line
            echo "$smiles" > "${compound_id}.smi"
            
            # Convert SMILES to MOL2
            obabel -ismi "${compound_id}.smi" -omol2 -O "${compound_id}.mol2" --gen3D --minimize -h
            
            # Convert MOL2 to PDBQT using MGLTools (Python 2)
            "${pthnsh}/pythonsh" "${MGLT}/prepare_ligand4.py" -l "${compound_id}.mol2" -o "${compound_id}.pdbqt" 
        fi
    done < "$csv_file"
}

# Main function
main() {
    create_pdbqt_from_smiles 'smiles.csv'
}

main

