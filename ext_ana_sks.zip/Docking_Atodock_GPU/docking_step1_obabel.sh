#!/bin/bash

# Path settings
export MGLT=/home/sumanta.kumar@sapt.local/test/mgltools_x86_64Linux2_1.5.7/MGLToolsPckgs/AutoDockTools/Utilities24
export VinaPath=/home/sumanta.kumar@sapt.local/anaconda3/envs/docking/bin
export autogrid4=/home/sumanta.kumar@sapt.local/anaconda3/envs/docking/bin/autogrid4
export pthnsh=/home/sumanta.kumar@sapt.local/test/mgltools_x86_64Linux2_1.5.7/bin
export REC_PDBQT_PATH=/home/sumanta.kumar@sapt.local/UMICH2/sp_shared_docking/cpu_docking/rec.pdbqt  # Update this path

echo "written by Sumant K. Sahu"

# Function to create PDBQT files from SMILES in CSV
create_pdbqt_from_smiles() {
    csv_file=$1
    while IFS=, read -r compound_id smiles; do
        if [ "$compound_id" != "Compound_ID" ]; then  # Skip header line
            mkdir -p "$compound_id"
            echo "$smiles" > "${compound_id}/${compound_id}.smi"
            obabel -ismi "${compound_id}/${compound_id}.smi" -opdbqt -O "${compound_id}/${compound_id}.pdbqt" --gen3D --minimize -h
        fi
    done < "$csv_file"
}

# Run Docking Separately in individual directories
run_docking() {
    csv_file=$1
    while IFS=, read -r compound_id smiles; do
        if [ "$compound_id" != "Compound_ID" ]; then  # Skip header line
            if [ -d "$compound_id" ]; then 
                cd "$compound_id"
                echo "Working on $compound_id"
                ligand_file="${compound_id}.pdbqt"
                if [ ! -f "$ligand_file" ]; then
                    echo "Ligand file for $compound_id not found!"
                    cd ../
                    continue
                fi
                cp $REC_PDBQT_PATH .  # Copy rec.pdbqt to the current directory
                $pthnsh/pythonsh $MGLT/prepare_gpf4.py -l "$ligand_file" -r rec.pdbqt -p spacing=0.403 -p npts='102,60,74' -p gridcenter='187.325,254.967,206.184' -o ${compound_id}.gpf
                sed -i 's/receptor.pdbqs/rec.pdbqt/g' ${compound_id}.gpf  # Replace receptor.pdbqs with rec.pdbqt
                autogrid4 -p ${compound_id}.gpf -l ${compound_id}.glg
                $pthnsh/pythonsh $MGLT/prepare_dpf42.py -l "$ligand_file" -r rec.pdbqt -p ga_num_evals=30000000 -p ga_num_generations=30000 -p ga_pop_size=200 -p ga_run=20 -o Dock${compound_id}.dpf
                #autodock4 -p Dock${compound_id}.dpf -l Dock${compound_id}.dlg
                autodock_gpu_256wi  -L "$ligand_file"  -M rec.maps.fld  --dlgoutput 1  --npdb 1 --A 0  --nrun 1000  --nev 3000000  --ngen 100000  --lsit 600  --psize 600   --mrat 1 -N docking.log  
                cd ../
            fi
        fi
    done < "$csv_file"
}

# Convert PDBQT files of ligands using Open Babel
convert_pdbqt_to_pdb() {
    csv_file=$1
    while IFS=, read -r compound_id smiles; do
        if [ "$compound_id" != "Compound_ID" ]; then  # Skip header line
            if [ -d "$compound_id" ]; then
                cd "$compound_id"
                ligand_file="${compound_id}.pdbqt"
                if [ -f "$ligand_file" ]; then
                    obabel "$ligand_file" -O "${compound_id}.pdb"
                else
                    echo "Ligand file for $compound_id not found!"
                fi
                cd ../
            fi
        fi
    done < "$csv_file"
}

# Main function to execute all tasks
main() {
    create_pdbqt_from_smiles 'smiles.csv'
    run_docking 'smiles.csv'
    convert_pdbqt_to_pdb 'smiles.csv'
}

main

