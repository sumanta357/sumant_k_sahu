#!/bin/bash

# Load Conda and activate environment
source ~/anaconda3/etc/profile.d/conda.sh  # Adjust if your conda path is different
conda activate gmx_MMPBSA

# Load GROMACS environment
source /home/apps/gromacs-2023-3/bin/GMXRC

# Prompt user for input files (relative or absolute paths)
read -p "Enter the path to the TPR file: " TPR_FILE
read -p "Enter the path to the XTC file: " XTC_FILE
read -p "Enter the path to the index file: " INDEX_FILE
read -p "Enter the path to the topology file: " TOPOLOGY_FILE

# Create and move into MMGBSA directory
mkdir -p MMGBSA
cd MMGBSA || exit

# Define input file name
INPUT_FILE="mmgbsa_per_res_gb.in"

# Write MMGBSA input content
cat <<EOF > "$INPUT_FILE"
Sample input file for decomposition analysis
This input file is meant to show only that gmx_MMPBSA works. Althought,
we tried to used the input files as recommended in the Amber manual,
some parameters have been changed to perform more expensive calculations
in a reasonable amount of time. Feel free to change the parameters 
according to what is better for your system.

&general
sys_name="Decomposition",
startframe=3000,
endframe=10000,
forcefields="leaprc.protein.ff14SB"
/ 
&gb
igb=5, saltcon=0.150,
/ 
#make sure to include at least one residue from both the receptor
#and ligand in the print_res mask of the &decomp section.
#this requirement is automatically fulfilled when using the within keyword.
#http://archive.ambermd.org/201308/0075.html
&decomp
idecomp=2, dec_verbose=3,
print_res="within 4"
/ 
EOF

# Run gmx_MMPBSA from within MMGBSA directory
gmx_MMPBSA -O -i "$INPUT_FILE" \
  -cs "$TPR_FILE" \
  -ct "$XTC_FILE" \
  -ci "$INDEX_FILE" \
  -cg 1 13 \
  -cp "$TOPOLOGY_FILE" \
  -o FINAL_RESULTS_MMGBSA.dat \
  -eo FINAL_RESULTS_MMGBSA.csv

