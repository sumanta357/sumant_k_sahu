#!/bin/bash
# This works for the INPUT PDB files that are having pdbxxxx.ent as file extension.
# If the extension of INPUT PDB FILES is *.pdb, then edit ---> for i in pdb*ent -->to---> for i in *.pdb
# find_neighbor_pdb binary should be present in the PWD
for i in *.cif;
do
	./find_neighbor_pdb -f $i -r 6.0 -p -t -X
echo " ******** DONE for $i ********";
done;
echo " ******** <<<<< See the Folders named OutDir for the pocket files >>>>> *********"
