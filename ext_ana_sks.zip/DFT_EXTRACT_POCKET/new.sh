#!/bin/usr/env bash

for n in *pdb;
do
   ./find_neighbor_pdb -f $n -r 6.0 -p -t -X
done
