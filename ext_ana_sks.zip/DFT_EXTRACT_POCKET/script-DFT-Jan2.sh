# RB wrote the script for preparing the I/P files for DFT calculation
# Apr 2023

echo "
# This script requires the pocket in the name "ar.pdb" 
# 2 files are to be present in the I/P directory. 1) ar.pdb 2) script file
Please delete or comment out "#" the exit command below this line "; 
#exit
pymol=/home1/apps/pymol-open/bin/pymol
cat ar.pdb | grep ATOM | cut -c18-26 | sort -u | cut -c6-9 | sed 's: ::g' | sort -V > 1.txt
cat 1.txt | while read i; do echo "
$i+1
"|bc > i+1.txt; 
if (( $(grep -A1 "$i" 1.txt | grep -v "$i") != `cat "i+1.txt"` ));  
then echo $i; 
fi; 
done > 2.txt
tail -1 1.txt >> 2.txt; sort -u 2.txt | sort -V > T; mv T 2.txt; 
echo " ++++++++++++++++++ 2.txt contains the RESIDUES to be added with Oxygen ++++++++++++++";

echo "
load ar.pdb
cmd.h_add(\"ar\");cmd.sort(\"ar extend 1\")
save ar-afteraddHpymol.pdb 
quit " > add-H.pml
$pymol -u add-H.pml
echo "
load ar-afteraddHpymol.pdb
cmd.show_as(\"lines\"     ,\"ar-afteraddHpymol\")" > load.pml
cat 2.txt | while read i; do echo "
select resi "$i"
save RES-${i}.mol2, sele"; done >> load.pml
echo "quit" >> load.pml
$pymol -u load.pml
echo "

******************* DONE creating MOL2 files for residues to be Oxygen added ********************";

cat ar.pdb | grep ATOM | cut -c22 | sort -u | grep -v '^$' > chainID

for z in `cat 2.txt`; 
do
if [ ! -f RES-${z}.mol2 ]
then
echo "************ Residues to be added with Oxygen ARE NOT THE SAME as Residues present in FOLDER - ${z} ************";
else
echo "================ Residues to be added with Oxygen - ALL FINE - PROCEED =========================";
fi
done

echo "


########### STARTING with CREATING PYMOL SCRIPT FOR OXYGEN ADDING - Adding-O.pml ############

";
for m in RES-*mol2; do cat $m | awk '/BOND/,/SUBSTRUCT/' | grep -w -oP '3 \K\w+' | sort -u | while read ATMNUM; do cat $m | grep "^${ATMNUM}[[:space:]]" | grep "[[:space:]]H[[:space:]]" | awk '{print $1}'; done > atom.txt;  
echo "load $m" > Adding-O.pml
echo 'cmd.edit("('${m%.*}'`'`cat atom.txt`')",pkresi=1)' >> Adding-O.pml
echo "replace O,4,2" >> Adding-O.pml
echo "save ${m%.*}-OH.pdb
quit" >> Adding-O.pml
$pymol -u Adding-O.pml ; 
done
echo " ******************** DONE ADDING OXYGEN TO ALL RESIDUES in map-RES-ATOMNUMB.txt ******************

NOW STARTING WITH CHECKING IF HIS RESIDUE IS NEUTRAL";

# Deleting one HYDROGEN on HISTIDINE, to make it NEUTRAL

# This segment is for considering the OH added HIS and not HIS from ar.pdb
for i in RES-*OH.pdb; do echo $i `cat $i | cut -c18-20 | grep HIS| sort -u`; done | awk '{if ($2 != "") print $1}'| sort -u > HIS-with-OH-added.txt;
for i in `cat HIS-with-OH-added.txt`; do
echo "
load $i
select *
save res-H-del-`echo $i | cut -f2 -d "-"`.mol2
quit " > Del-H.pml;
$pymol -u Del-H.pml; 
done
# Complete segment for considering HIS that has OH added 

# This below segment is for considering HIS which are not DISCONT and have no OH to be added.
if [[ `wc -l HIS-with-OH-added.txt | awk '{print $1}'` != "0" ]]
then
cat HIS-with-OH-added.txt | while read i; do cat $i | grep ATOM | grep HIS | cut -c18-26 | sort -u; done | tr "\n" "|" | sed 's:|$::g'| awk '{print}' > t-HIS
cat ar-afteraddHpymol.pdb | grep ATOM | grep HIS | cut -c18-26 | sort -u | grep -Ev "`cat t-HIS`" | while read HIS; do echo "
load ar-afteraddHpymol.pdb
select resi `echo ${HIS}| cut -c6-9 | sed 's: ::g'` and chain `echo "${HIS}" | cut -c5`
save res-H-del-`echo ${HIS}|cut -c6-9 | sed 's: ::g'`.mol2, sele
quit " > Del-H.pml; 
$pymol -u Del-H.pml; 
done;
else
	cat ar-afteraddHpymol.pdb | grep ATOM | grep HIS | cut -c18-26 | sort -u | while read HIS; do echo "
load ar-afteraddHpymol.pdb
select resi `echo ${HIS}| cut -c6-9 | sed 's: ::g'` and chain `echo "${HIS}" | cut -c5`
save res-H-del-`echo ${HIS}|cut -c6-9 | sed 's: ::g'`.mol2, sele
quit " > Del-H.pml;
$pymol -u Del-H.pml;
done;
fi

# Completion of the above mentioned segment 

# Picking ATOMNUMB for H deletion
for j in res-H-del-*mol2; do if [[ `cat $j | awk '/BOND/,/SUBSTR/'| grep -w -oP '8 \K\w+'| sort -u | while read i; do grep "^$i[[:space:]]" $j | grep "[[:space:]]H[[:space:]]"; done` != "" ]]; then  cat $j | awk '/BOND/,/SUBSTR/'| grep -w -oP '8 \K\w+'| sort -u | while read i; do grep "^$i[[:space:]]" $j | grep "[[:space:]]H[[:space:]]" | awk '{print $1}' | sed 's: \s+::g'; done > ID; echo "
load $j
remove id `cat ID`
save H-for-${j}-deleted.pdb
quit " > Del-H-2.pml; $pymol -u Del-H-2.pml; fi; done
# END OF MAKING HISTIDINE RESIDUE NEUTRAL 
echo "

DONE WITH HISTIDINE CHECK FOR NEUTRALITY 

";


# The below segment combines all new Oxy added and Hyd removed residues and creates a new file called pro.pdb
if [ ! -f H-for-*deleted.pdb ]
then
echo " +++++++++++++  NO HIS RESIDUE IS CHARGED. ALL NEUTRAL ++++++++++++++++++++++";
else 
echo " +++++++++++++ HIS residue found CHARGED, REPAIRED TO NEUTRAL ++++++++++++++++";
fi;

mkdir OTH-HIS; 
ls H-for-res-H-del-*pdb | sed 's:H-for-res-H-del-::g;s:.mol2-deleted.pdb::g'| while read m; do mv RES-${m}-OH.pdb OTH-HIS/; done;
for i in RES-*-OH.pdb H-for-*deleted.pdb; do cat $i | grep ATOM | cut -c18-26 | sort -u | grep -v '^$'; done | tr "\n" ";" | sed 's/;/[[:space:]]\n/g' | tr "\n" "|" | sed 's:|$::g' | awk '{print}' > remove.txt
cat ar-afteraddHpymol.pdb | grep -Ev "`cat remove.txt`"| grep "^ATOM" > pro.pdb

cat RES*-OH.pdb H-for-*deleted.pdb >> pro.pdb
cat pro.pdb | grep "^ATOM  "| cut -c22-26 | sort -u | sort -V| while read RES; do grep "${RES}[[:space:]]" pro.pdb ; done > P; echo "
TER
END" >> P;
cut -c-72 P > 1; cut -c73-100 P | sed 's:^[A-Z][[:space:]]:  :g' >2; paste -d ";" 1 2 | sed 's:;::g' > P.pdb
echo "load P.pdb
select *
save PROTEIN.pdb
quit " > final.pml
$pymol -u final.pml;
echo "

<<<<<< PROTEIN.pdb IS THE FINAL FILE THAT CONTAINS ALL PROTEIN ATOMS FOR A) OXYGEN ADD B) HYDROGEN REMOVAL >>>>

";

cat ar.pdb | grep "^HETATM" > L.pdb
cat PROTEIN.pdb L.pdb > PRO-LIG.pdb
echo " ITSY BITSY SPIDER ";

#mkdir FILES; 
#cp scr.sh ar.pdb PROTEIN.pdb FILES/
#rm -f *; cp FILES/* .;
#echo "************ ALL CLEAR *************"; 
